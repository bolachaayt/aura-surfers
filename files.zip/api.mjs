import { getStore } from "@netlify/blobs";
import { scryptSync, randomBytes, timingSafeEqual } from "node:crypto";

export const config = { path: "/api" };
const R = (o, s = 200) => Response.json(o, { status: s });
const MAPS = ["city", "neon", "deserto", "gelo"];

export default async (req) => {
  const db = getStore("aura");
  const b = await req.json().catch(() => ({}));
  const rd = (k) => db.get(k, { type: "json" });
  const wr = (k, v) => db.setJSON(k, v);
  const clean = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 16);
  const hash = (p, salt) => scryptSync(String(p), salt, 32).toString("hex");
  const isAdmin = (u) => !!u && u === clean(process.env.ADMIN_USER);
  const a = b.a;

  if (a === "register" || a === "login") {
    const n = clean(b.user), p = String(b.pass || "");
    if (n.length < 3 || p.length < 6) return R({ err: "Usuário (3+ letras/números) e senha (6+) são obrigatórios" }, 400);
    let u = await rd("u_" + n);
    if (a === "register") {
      if (u) return R({ err: "Esse usuário já existe" }, 409);
      const salt = randomBytes(8).toString("hex");
      u = { salt, h: hash(p, salt), best: 0, bt: 0 };
      await wr("u_" + n, u);
    } else if (!u || !timingSafeEqual(Buffer.from(hash(p, u.salt)), Buffer.from(u.h))) {
      return R({ err: "Usuário ou senha inválidos" }, 401);
    }
    const t = randomBytes(16).toString("hex");
    await wr("s_" + t, { u: n });
    return R({ token: t, user: n, admin: isAdmin(n), best: u.best, bt: u.bt });
  }

  const w = (await rd("world")) || { map: "city", events: [], announce: null };
  if (a === "state") return R({ world: w, board: (await rd("board")) || [] });

  const tk = String(b.token || "").replace(/[^a-f0-9]/g, "");
  const s = tk && (await rd("s_" + tk));
  if (!s) return R({ err: "Sessão expirada, entre de novo" }, 401);
  const n = s.u;

  if (a === "me") {
    const u = await rd("u_" + n);
    return R({ user: n, admin: isAdmin(n), best: u.best, bt: u.bt });
  }

  if (a === "score") {
    const sc = Math.max(0, Math.min(1e7, +b.score || 0));
    const t = Math.max(0, Math.min(36000, +b.t || 0));
    const u = await rd("u_" + n);
    if (sc > u.best) u.best = sc;
    if (b.nc && t > u.bt) u.bt = t;
    await wr("u_" + n, u);
    let bd = (await rd("board")) || [];
    bd = bd.filter((x) => x.u !== n).concat({ u: n, s: u.best, t: u.bt }).sort((x, y) => y.s - x.s).slice(0, 10);
    await wr("board", bd);
    return R({ best: u.best, bt: u.bt });
  }

  if (a === "admin") {
    if (!isAdmin(n)) return R({ err: "Sem permissão" }, 403);
    const p = b.patch || {};
    if (MAPS.includes(p.map)) w.map = p.map;
    if (p.addEvent && w.events.length < 8)
      w.events.push({ id: Date.now(), name: String(p.addEvent.name || "").slice(0, 30), mult: Math.min(5, Math.max(1, +p.addEvent.mult || 1)) });
    if (p.delEvent) w.events = w.events.filter((e) => e.id !== p.delEvent);
    if (p.announce) w.announce = { id: Date.now(), text: String(p.announce).slice(0, 200) };
    await wr("world", w);
    return R({ world: w });
  }
  return R({ err: "Ação inválida" }, 400);
};
